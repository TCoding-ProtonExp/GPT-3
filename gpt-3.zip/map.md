# This is your Map 🗺 
**Come here if you need to 🧭 navigate around your REPL (a REPL is the interactive programme we're using to code)**

🦉 **ProTip:** Click the "Markdown" tab on the top-right to open the map any time you need it!

## 👀 What's around me??
1. **To the far left pane you see a file tree.**  This is a list of files where we'll find everything we need. You can open and explore each file to see what clues you might find to puzzle things out.

Here are your files and what they do:

**👩‍💻 main.py** is a file for writing code in python (change your code in this file to make your program behave differently)

**🏅 achievements.txt** is where you can track wins and find your next mission

**🗃 inventory.txt** where useful things live

**🦹‍♂️roles.txt** where you assign roles

**🗺 map.md** for when you're lost

3. **In the centre pane is your main window**. Click on a file for it to open in the centre. 

4. **On your right lives your console & markdown window pane**. Hit the green **Run Button** to initiate your program. 

5. When you **Run** code, its **input** and **output** happen in the console. What that means is if you want to interact with your program you do that in your console.
6. Each time you **run** it, you can **type your input** in the console and see what output it gives you!

### All around you are friends 👯‍♀️❤️🥷. They're here to support you with your adventures.

**At Mindjoy we love to have hard fun!** And that starts with **being curious and exploring your surroundings**... 🤔

_What do you think you should do next??_