### Please dont remove my access to this project. I like to fiddle with it and see how I can improve it.

import openai
import sys
sys.path.append('.lesson')
import openai_functions as gpt3
from colorama import init, Fore, Back, Style
init(autoreset=True)

name="Mr Krabs"

print(Fore.BLUE + f"🤖💬 Hello! I'm {name}. I Like MONEY and dont like you.")
print("🧐💬 What should I do for you?", end="")
chosen_topic = input()

prompt = f"""f
I'm a 18-years-old.
Write an essay on {chosen_topic}:
\n
"""
result = gpt3.complete(prompt, max_tokens=250)



print()
print()
print(Back.GREEN + "Awesome :) Here's our output:", end="")
print(Fore.GREEN + " " + result)

print(Fore.BLUE + "")

