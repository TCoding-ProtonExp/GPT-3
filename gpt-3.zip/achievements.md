## 🏔 Mission 1: Get your AI-assitant working by completing the program.
====================================
### Oh gosh, a robot ate your teacher and has given you ton of homework 🤖📝📝📝! 

- Work in teams to program an AI-homework assitant to help you with homework.
- Mark you achievements with an `x` as you complete them.

====================================
### Achievements:

- [x] 🚩🦁 "Brave foot forward": Opened Replit like a real hacker!
- [x] 🚩🔎 "Mystery Solved!": Discovered GPT-3 code snippet
- [x] 🚩🏡 "Home sweet home": GPT-3 code snippet found a home.
- [x] 🚩🏃‍♀️ "Run, run, run": See your program work in the console.
- [x] 🚩🎮 "Fun and Games": Played with some inputs.

====================================
## 🏔 Mission 2: Program GPT-3 with the right prompt so it can do your homework.

### 📝Homework: Write a factual essay about solar farms, their benefits and best places to build them.
====================================
### Achievements: 0/5
- [x] 🚩 Modified the GPT-3 prompt to be for a 14 year old doing research.
- [x] 🚩 Got GPT-3 to write a list of facts about solar farms.
- [x] 🚩 Got GPT-3 to suggest great places in the world to build solar farms.
- [x] 🚩 Modified the GPT-3 prompt to write an essay.
- [x] 🚩 Edit your tokens to change the length of your AI-generated output.

====================================
## 🏔 Mission 3: Edit the program so that your output more accurately represents what your bot does.
====================================
### Achievements: 0/2
- [x] 🚩 Changed the name of our AI-Bot.
- [x] 🚩 Modified the print function to tell us about our AI-bot and what it does (remember our mission: what were we trying to get our AI bot to do today?)
  
====================================
## 🏔 Bonus Mission: Edit the program so that you can do creative tasks with GPT-3.
====================================
### Achievements:
- [x] 🚩 Created a bot that can do creative writing like poems, stories, lyrics, etc. You can get super creative!
- [x] 🚩 Modified your prompt in such a way that you show GPT-3 who the program is for.
  
### 🥳 I've mastered doing my homework with AI!!! 🦹‍♂ Many more adventures together await...


## 🤓 Reflect & Submit
- [x] 🚩 Complete the [Feedback Form](https://teammindjoy.typeform.com/to/jtTY1wAr)
- [x] 🚩 Hit the `Submit` Button in the top right hand corner.